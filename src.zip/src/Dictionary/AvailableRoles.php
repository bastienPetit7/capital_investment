<?php

namespace App\Dictionary;

class AvailableRoles
{
    public const ROLE_ADMIN = "ROLE_ADMIN";
    public const ROLE_INVESTOR = "ROLE_INVESTOR";
}