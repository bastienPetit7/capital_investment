<?php

namespace App\Dictionary;

class Currency
{
    public const EURO_SIGN = "€";
    public const DOLLAR_SIGN = "$";
    public const FRANC_SUISSE_SIGN = "CHF";
}