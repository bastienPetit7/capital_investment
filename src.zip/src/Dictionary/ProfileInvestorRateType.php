<?php

namespace App\Dictionary;

class ProfileInvestorRateType
{
    public const INVESTOR_INTEREST_CLASSIC = "CLASSIC";
    public const INVESTOR_INTEREST_COMPOUND = "COMPOUND";
}