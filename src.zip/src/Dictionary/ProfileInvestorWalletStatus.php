<?php

namespace App\Dictionary;

class ProfileInvestorWalletStatus
{
    public const INVESTOR_STARTER = "STARTER";
    public const INVESTOR_SILVER = "SILVER";
    public const INVESTOR_GOLD = "GOLD";
    public const INVESTOR_PLATINUM = "PLATINUM";
}