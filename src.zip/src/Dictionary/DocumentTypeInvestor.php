<?php

namespace App\Dictionary;

class DocumentTypeInvestor
{
    public const OPERATION_STATEMENT = "Operation Statement";
    public const CONTRACTS = "Contracts";
    public const REPORTING = "Reporting";
    public const PERSONAL_DOCUMENTS = "Personal Documents";
    public const MENTIONS_LEGALS = "Legal Notice";
}