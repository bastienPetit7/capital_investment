<?php

namespace App\Dictionary;

class AvailableStatusMode
{
    public const ACTIVE = "ACTIVE";
    public const GHOST = "GHOST";
}