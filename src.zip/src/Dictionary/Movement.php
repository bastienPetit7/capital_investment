<?php

namespace App\Dictionary;

class Movement
{
    public const DEPOSIT = "DEPOSIT";
    public const WITHDRAWAL = "WITHDRAWAL";
    public const EARNING = "EARNING";
    public const BONUS = "BONUS";
}