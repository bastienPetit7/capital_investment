<?php

namespace App\Classe\Monetico\Collections;


abstract class Language
{
    // German
    const DE='DE';

    // English
    const EN='EN';

    // Spanish
    const ES='ES';

    // French
    const FR='FR';

    // Italian
    const IT='IT';

    // Japan
    const JA='JA';

    // Dutch
    const NL='NL';

    // Portuguese
    const PT='PT';

    // Swedish
    const SV='SV';
}