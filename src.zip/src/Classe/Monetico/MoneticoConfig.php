<?php


namespace App\Classe\Monetico; 

class MoneticoConfig{

    public const CLE_MAC = "12345678901234567890123456789012345678P0";
    public const TPE = "0000001"; 
    public const CODE_SOCIETE = "0904d2d95bf7f0fcd6fb"; 
    public const PAYMENT_PAGE_URL = "https://p.monetico-services.com/test/paiement.cgi"; 


}

