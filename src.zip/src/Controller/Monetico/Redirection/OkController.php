<?php

namespace App\Controller\Monetico\Redirection;

use App\Classe\Monetico\Response\ResponseInterface;
use App\Entity\Order;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class OkController extends AbstractController
{


    /**
     * @Route("/cgi/success", name="cgi_success")
     *
     * @return void
     */
    public function paiementOk()
    {

        


    }




}